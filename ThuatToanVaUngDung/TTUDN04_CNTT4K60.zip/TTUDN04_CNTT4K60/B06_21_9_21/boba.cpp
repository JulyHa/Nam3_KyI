#include<bits/stdc++.h>
using namespace std;

typedef pair<string,pair<int,int>> SV;
#define ten first
#define tuoi second.first
#define diem second.second
int main()
{
	SV x={"chi pheo",{15,4}};
	cout<<x.ten<<" "<<x.tuoi<<" "<<x.diem;
}


